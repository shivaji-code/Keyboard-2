package com.glassboard.keyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private lateinit var p: Prefs
    private lateinit var box: LinearLayout
    private val palette = intArrayOf(
        0xFF007AFF.toInt(), 0xFF34C759.toInt(), 0xFFFF9500.toInt(), 0xFFFF3B30.toInt(),
        0xFFAF52DE.toInt(), 0xFFFF2D55.toInt(), 0xFF5AC8FA.toInt(), 0xFF8E8E93.toInt()
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun add(v: View, top: Int = 8) {
        box.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })
    }

    private fun header(t: String) = add(TextView(this).apply {
        text = t; textSize = 18f; setTypeface(null, Typeface.BOLD)
    }, 24)

    private fun note(t: String) = add(TextView(this).apply { text = t; textSize = 13f; alpha = 0.7f })

    private fun button(t: String, f: () -> Unit) = add(Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { f() }
    })

    private fun toggle(label: String, key: String, def: Boolean) = add(Switch(this).apply {
        text = label; isChecked = p.b(key, def)
        setOnCheckedChangeListener { _, v -> p.put(key, v) }
    })

    private fun seek(label: String, key: String, min: Int, max: Int, def: Int) {
        val cur = p.i(key, def)
        val t = TextView(this).apply { text = "$label: $cur" }
        val s = SeekBar(this).apply { this.max = max - min; progress = cur - min }
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, v: Int, u: Boolean) { t.text = "$label: ${v + min}"; p.put(key, v + min) }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        add(t, 14)
        add(s, 0)
    }

    private fun choice(label: String, key: String, opts: List<String>, def: Int, values: List<String>? = null) {
        add(TextView(this).apply { text = label }, 14)
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, opts)
        val cur = if (values == null) p.i(key, def) else values.indexOf(p.s(key, values[def])).coerceAtLeast(0)
        sp.setSelection(cur)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (values == null) p.put(key, pos) else p.put(key, values[pos])
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        add(sp, 0)
    }

    private fun accentPicker() {
        add(TextView(this).apply { text = "Accent colour (return key, selections)" }, 14)
        val row = LinearLayout(this)
        fun draw() {
            row.removeAllViews()
            for (c in palette) {
                val v = View(this)
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(c)
                    if (c == p.accent) setStroke(dp(3), Color.BLACK)
                }
                v.setOnClickListener { p.put("accent", c); draw() }
                row.addView(v, LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(10) })
            }
        }
        draw()
        add(row, 6)
        val hex = EditText(this).apply { hint = "Custom hex, e.g. FF6A00"; setSingleLine() }
        add(hex)
        button("Apply custom colour") {
            try { p.put("accent", Color.parseColor("#" + hex.text.toString().trim().removePrefix("#"))); draw() }
            catch (e: Exception) { Toast.makeText(this, "Invalid colour", Toast.LENGTH_SHORT).show() }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = Prefs(this)
        val sv = ScrollView(this)
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(48)) }
        sv.addView(box)
        setContentView(sv)

        add(TextView(this).apply { text = "GlassBoard"; textSize = 28f; setTypeface(null, Typeface.BOLD) })
        note("Turn the keyboard on, switch to it, then tap the box below to try it. Settings apply the next time the keyboard opens.")
        button("1. Enable GlassBoard") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        button("2. Switch to GlassBoard") { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
        add(EditText(this).apply { hint = "Tap here to test the keyboard"; minLines = 2 })

        header("Look")
        choice("Theme", "theme", listOf("Auto (follow phone)", "Light", "Dark"), 0)
        choice("Style", "style", listOf("iOS solid", "Liquid glass"), 0)
        accentPicker()
        seek("Glass strength", "glass", 0, 100, 60)
        seek("Background blur (Android 12+)", "blur", 0, 100, 50)
        seek("Key row height (dp)", "keyH", 40, 70, 52)
        seek("Key corner radius (dp)", "radius", 0, 16, 6)
        seek("Letter size (sp)", "textSize", 16, 30, 22)
        choice("Font", "font", listOf("Sans", "Sans medium", "Serif", "Monospace", "Casual", "Cursive"), 0,
            listOf("sans-serif", "sans-serif-medium", "serif", "monospace", "casual", "cursive"))
        choice("One-handed mode", "oneHand", listOf("Off", "Keyboard on left", "Keyboard on right"), 0)
        toggle("Number row on top", "numRow", false)
        button("Pick background picture") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 7)
        }
        button("Remove background picture") {
            File(filesDir, "bg.jpg").delete(); p.put("bgImage", "")
        }

        header("Typing")
        toggle("Autocorrect", "autoCorrect", true)
        toggle("Suggestions bar", "suggest", true)
        toggle("Auto-capitalise", "autoCap", true)
        toggle("Double space inserts full stop", "dblSpace", true)
        toggle("Key preview pop-up", "preview", true)
        toggle("Vibration", "haptic", true)
        toggle("Key sounds", "sound", false)
        note("Tip: hold the space bar and slide to move the cursor. Hold a letter for accents. Hold the smiley key to switch keyboards.")

        header("Data")
        button("Clear clipboard history (keeps pinned)") { Db(this).clearUnpinned(); Toast.makeText(this, "Done", Toast.LENGTH_SHORT).show() }
        button("Forget learned words") { Db(this).clearLearned(); Toast.makeText(this, "Done. Restart keyboard to apply.", Toast.LENGTH_SHORT).show() }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 7 && res == RESULT_OK) data?.data?.let { saveBg(it) }
    }

    private fun saveBg(u: Uri) {
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
            val s = maxOf(1, maxOf(o.outWidth, o.outHeight) / 1200)
            val o2 = BitmapFactory.Options().apply { inSampleSize = s }
            val bmp = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return
            File(filesDir, "bg.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            p.put("bgImage", "bg.jpg")
            Toast.makeText(this, "Background set", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not load that picture", Toast.LENGTH_SHORT).show()
        }
    }
}
