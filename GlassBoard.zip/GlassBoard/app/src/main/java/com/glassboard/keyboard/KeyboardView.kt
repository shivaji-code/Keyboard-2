package com.glassboard.keyboard

import android.content.Context
import android.graphics.*
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.PopupWindow

enum class KT { CHAR, SHIFT, DEL, NUM, SYM, ABC, EMOJI, SPACE, ENTER, SPACER }

class Key(val t: KT, val label: String = "", val w: Float = 1f, val alts: String = "")
class LKey(val key: Key, val r: RectF)

object Layouts {
    private val A = mapOf(
        "a" to "àáâäæãåā", "e" to "èéêëēėę", "i" to "îïíīįì", "o" to "ôöòóœøōõ",
        "u" to "ûüùúū", "c" to "çćč", "n" to "ñń", "s" to "ßśš", "y" to "ÿý", "z" to "žźż",
        "l" to "ł", "d" to "ð", "₹" to "\$€£¥", "0" to "°", "-" to "–—•", "'" to "‘’`",
        "\"" to "“”„«»", "?" to "¿", "!" to "¡", "." to "…", "&" to "§"
    )

    private fun ch(s: String, w: Float = 1f) = s.map { Key(KT.CHAR, it.toString(), w, A[it.toString()] ?: "") }
    private fun ch(l: List<String>, w: Float = 1f) = l.map { Key(KT.CHAR, it, w, A[it] ?: "") }
    private fun bottom(left: Key) = listOf(left, Key(KT.EMOJI, "", 1.3f), Key(KT.SPACE, "space", 5.2f), Key(KT.ENTER, "return", 2.0f))

    fun get(mode: Int, numRow: Boolean): List<List<Key>> = when (mode) {
        1 -> listOf(
            ch("1234567890"),
            ch(listOf("-", "/", ":", ";", "(", ")", "₹", "&", "@", "\"")),
            listOf(Key(KT.SYM, "#+=", 1.5f)) + ch(".,?!'", 1.4f) + Key(KT.DEL, "", 1.5f),
            bottom(Key(KT.ABC, "ABC", 1.4f))
        )
        2 -> listOf(
            ch("[]{}#%^*+="),
            ch(listOf("_", "\\", "|", "~", "<", ">", "\$", "€", "£", "•")),
            listOf(Key(KT.NUM, "123", 1.5f)) + ch(".,?!'", 1.4f) + Key(KT.DEL, "", 1.5f),
            bottom(Key(KT.ABC, "ABC", 1.4f))
        )
        else -> {
            val rows = mutableListOf<List<Key>>()
            if (numRow) rows.add(ch("1234567890"))
            rows.add(ch("qwertyuiop"))
            rows.add(listOf(Key(KT.SPACER, "", 0.5f)) + ch("asdfghjkl") + Key(KT.SPACER, "", 0.5f))
            rows.add(listOf(Key(KT.SHIFT, "", 1.5f)) + ch("zxcvbnm") + Key(KT.DEL, "", 1.5f))
            rows.add(bottom(Key(KT.NUM, "123", 1.4f)))
            rows
        }
    }
}

class KeyboardView(ctx: Context, private val p: Prefs, private val cb: Callback) : View(ctx) {
    interface Callback {
        fun onText(s: String)
        fun onSpace()
        fun onDelete()
        fun onEnter()
        fun onEmoji()
        fun onEmojiLong()
        fun onCursor(steps: Int)
    }

    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d
    private fun sp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)
    private fun withA(c: Int, a: Int) = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private var th: Th = Theme.build(ctx, p)
    private var tf: Typeface = Typeface.create(p.font, Typeface.NORMAL)
    private var mode = 0
    var shift = 0
        private set
    private var manual = false
    private var lastShiftTap = 0L
    private var rows: List<List<Key>> = Layouts.get(0, p.numRow)
    private val keys = ArrayList<LKey>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private var enterLabel = "return"
    private var enterAccent = false

    private var down: LKey? = null
    private var activeId = -1
    private var longDone = false
    private var cursorMode = false
    private var cursorX = 0f
    private var curX = 0f
    private var altKey: LKey? = null
    private var altSel = 0
    private var alts: List<String> = emptyList()
    private var popLeft = 0f
    private var popCell = 0f
    private var locX = 0
    private var delN = 0
    private val hnd = Handler(Looper.getMainLooper())
    private var pop: PopupWindow? = null
    private var bubble: Bubble? = null
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    // ---------------- public API ----------------
    fun applyPrefs() {
        th = Theme.build(context, p)
        tf = Typeface.create(p.font, Typeface.NORMAL)
        rows = Layouts.get(mode, p.numRow)
        requestLayout()
        layoutKeys()
        invalidate()
    }

    fun setMode(m: Int) {
        mode = m
        rows = Layouts.get(m, p.numRow)
        layoutKeys()
        invalidate()
    }

    fun setEnter(label: String, accent: Boolean) {
        enterLabel = label
        enterAccent = accent
        invalidate()
    }

    fun setAutoShift(on: Boolean) {
        if (shift == 2 || manual) return
        val n = if (on) 1 else 0
        if (n != shift) { shift = n; invalidate() }
    }

    // ---------------- layout ----------------
    override fun onMeasure(w: Int, hh: Int) {
        val n = Layouts.get(0, p.numRow).size
        setMeasuredDimension(MeasureSpec.getSize(w), (dp(p.keyH.toFloat()) * n + dp(14f)).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        layoutKeys()
    }

    private fun layoutKeys() {
        keys.clear()
        if (width == 0 || height == 0 || rows.isEmpty()) return
        val side = dp(3f)
        val top = dp(8f)
        val bot = dp(6f)
        val pitch = (height - top - bot) / rows.size
        val vg = pitch * 0.2f
        val hg = dp(6f)
        rows.forEachIndexed { i, row ->
            val total = row.sumOf { it.w.toDouble() }.toFloat()
            val unit = (width - 2 * side) / total
            var x = side
            val y = top + i * pitch
            for (k in row) {
                val w = k.w * unit
                if (k.t != KT.SPACER) keys.add(LKey(k, RectF(x + hg / 2, y + vg / 2, x + w - hg / 2, y + pitch - vg / 2)))
                x += w
            }
        }
    }

    private fun hit(x: Float, y: Float): LKey? {
        if (y < 0 || y > height) return null
        var best: LKey? = null
        var bd = Float.MAX_VALUE
        for (k in keys) {
            val r = k.r
            val dx = maxOf(r.left - x, 0f, x - r.right)
            val dy = maxOf(r.top - y, 0f, y - r.bottom)
            val dd = dx * dx + dy * dy
            if (dd < bd) { bd = dd; best = k }
        }
        return if (bd > dp(26f) * dp(26f)) null else best
    }

    // ---------------- drawing ----------------
    override fun onDraw(c: Canvas) {
        for (k in keys) drawKey(c, k)
    }

    private fun drawKey(c: Canvas, lk: LKey) {
        val k = lk.key
        val r = lk.r
        val pressed = lk === down && !cursorMode
        val special = k.t != KT.CHAR && k.t != KT.SPACE
        val accentKey = k.t == KT.ENTER && enterAccent
        val fill = when {
            accentKey -> th.accent
            k.t == KT.SHIFT && shift > 0 -> if (th.glass) withA(th.letter, 255) else th.letter
            pressed -> if (special) th.letter else th.special
            special -> th.special
            else -> th.letter
        }
        val rad = dp(p.radius.toFloat())
        paint.shader = null
        if (th.glass) {
            val a = Color.alpha(fill)
            paint.style = Paint.Style.FILL
            paint.shader = LinearGradient(r.left, r.top, r.left, r.bottom,
                withA(fill, (a * 1.25f).toInt()), withA(fill, (a * 0.8f).toInt()), Shader.TileMode.CLAMP)
            c.drawRoundRect(r, rad, rad, paint)
            paint.shader = null
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dp(0.8f)
            paint.color = Color.argb((60 + 120 * th.g).toInt(), 255, 255, 255)
            c.drawRoundRect(r, rad, rad, paint)
            paint.strokeWidth = dp(1f)
            paint.color = Color.argb((90 + 140 * th.g).toInt(), 255, 255, 255)
            c.drawLine(r.left + rad, r.top + dp(1f), r.right - rad, r.top + dp(1f), paint)
        } else {
            paint.style = Paint.Style.FILL
            paint.color = th.shadow
            rect.set(r.left, r.top + dp(1f), r.right, r.bottom + dp(1f))
            c.drawRoundRect(rect, rad, rad, paint)
            paint.color = fill
            c.drawRoundRect(r, rad, rad, paint)
        }
        val tc = if (accentKey) Color.WHITE else th.text
        when (k.t) {
            KT.CHAR -> text(c, if (shift > 0) k.label.uppercase() else k.label, r, sp(p.textSize.toFloat()), tc)
            KT.SPACE -> text(c, "space", r, sp(15f), tc)
            KT.ENTER -> text(c, enterLabel, r, sp(16f), tc)
            KT.NUM, KT.SYM, KT.ABC -> text(c, k.label, r, sp(16f), tc)
            KT.EMOJI -> text(c, "🙂", r, sp(22f), tc)
            KT.SHIFT -> shiftIcon(c, r, tc)
            KT.DEL -> delIcon(c, r, tc)
            else -> {}
        }
    }

    private fun text(c: Canvas, s: String, r: RectF, size: Float, color: Int) {
        paint.shader = null
        paint.style = Paint.Style.FILL
        paint.typeface = tf
        paint.color = color
        paint.textSize = size
        paint.textAlign = Paint.Align.CENTER
        val fm = paint.fontMetrics
        c.drawText(s, r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2, paint)
    }

    private fun shiftIcon(c: Canvas, r: RectF, color: Int) {
        val s = r.height() * 0.30f
        val cx = r.centerX()
        val cy = r.centerY() - (if (shift == 2) s * 0.1f else 0f)
        path.reset()
        path.moveTo(cx, cy - s)
        path.lineTo(cx + s, cy)
        path.lineTo(cx + s * 0.45f, cy)
        path.lineTo(cx + s * 0.45f, cy + s * 0.9f)
        path.lineTo(cx - s * 0.45f, cy + s * 0.9f)
        path.lineTo(cx - s * 0.45f, cy)
        path.lineTo(cx - s, cy)
        path.close()
        paint.color = color
        paint.strokeWidth = dp(1.6f)
        paint.strokeJoin = Paint.Join.ROUND
        paint.style = if (shift > 0) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
        c.drawPath(path, paint)
        if (shift == 2) {
            paint.style = Paint.Style.STROKE
            c.drawLine(cx - s * 0.45f, cy + s * 1.2f, cx + s * 0.45f, cy + s * 1.2f, paint)
        }
    }

    private fun delIcon(c: Canvas, r: RectF, color: Int) {
        val s = r.height() * 0.27f
        val cx = r.centerX()
        val cy = r.centerY()
        path.reset()
        path.moveTo(cx - s * 1.2f, cy)
        path.lineTo(cx - s * 0.5f, cy - s * 0.8f)
        path.lineTo(cx + s * 1.2f, cy - s * 0.8f)
        path.lineTo(cx + s * 1.2f, cy + s * 0.8f)
        path.lineTo(cx - s * 0.5f, cy + s * 0.8f)
        path.close()
        paint.color = color
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(1.6f)
        paint.strokeJoin = Paint.Join.ROUND
        c.drawPath(path, paint)
        c.drawLine(cx - s * 0.05f, cy - s * 0.35f, cx + s * 0.75f, cy + s * 0.35f, paint)
        c.drawLine(cx + s * 0.75f, cy - s * 0.35f, cx - s * 0.05f, cy + s * 0.35f, paint)
    }

    // ---------------- touch ----------------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                finishPending()
                val i = e.actionIndex
                activeId = e.getPointerId(i)
                curX = e.getX(i)
                startKey(hit(e.getX(i), e.getY(i)))
            }
            MotionEvent.ACTION_MOVE -> {
                val i = e.findPointerIndex(activeId)
                if (i >= 0) moveTo(e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                if (e.getPointerId(i) == activeId) { endKey(true); activeId = -1 }
            }
            MotionEvent.ACTION_CANCEL -> { endKey(false); activeId = -1 }
        }
        return true
    }

    private fun finishPending() {
        if (down != null) endKey(true)
    }

    private val repeatDel: Runnable = object : Runnable {
        override fun run() {
            if (down?.key?.t == KT.DEL) {
                cb.onDelete()
                delN++
                hnd.postDelayed(this, if (delN > 12) 35L else 70L)
            }
        }
    }

    private val longRun = Runnable {
        val lk = down ?: return@Runnable
        when (lk.key.t) {
            KT.CHAR -> {
                if (lk.key.alts.isEmpty()) return@Runnable
                val base = if (shift > 0) lk.key.label.uppercase() else lk.key.label
                val list = listOf(base) + lk.key.alts.map { if (shift > 0) it.toString().uppercase() else it.toString() }
                alts = list
                altKey = lk
                longDone = true
                showBubble(lk, list, true)
                altSel = altIndex(curX)
                bubble?.sel = altSel
                bubble?.invalidate()
            }
            KT.SPACE -> {
                cursorMode = true
                longDone = true
                cursorX = curX
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                invalidate()
            }
            KT.EMOJI -> { longDone = true; cb.onEmojiLong() }
            else -> {}
        }
    }

    private fun startKey(lk: LKey?) {
        down = lk
        longDone = false
        cursorMode = false
        altKey = null
        if (lk == null) return
        feedback(lk.key)
        when (lk.key.t) {
            KT.CHAR -> {
                if (p.preview) showBubble(lk, listOf(if (shift > 0) lk.key.label.uppercase() else lk.key.label), false)
                if (lk.key.alts.isNotEmpty()) hnd.postDelayed(longRun, 380)
            }
            KT.DEL -> {
                cb.onDelete()
                longDone = true
                delN = 0
                hnd.postDelayed(repeatDel, 400)
            }
            KT.SPACE -> hnd.postDelayed(longRun, 400)
            KT.EMOJI -> hnd.postDelayed(longRun, 500)
            else -> {}
        }
        invalidate()
    }

    private fun moveTo(x: Float, y: Float) {
        curX = x
        if (altKey != null) {
            val s = altIndex(x)
            if (s != altSel) { altSel = s; bubble?.sel = s; bubble?.invalidate() }
            return
        }
        if (cursorMode) {
            val step = dp(9f)
            val n = ((x - cursorX) / step).toInt()
            if (n != 0) { cb.onCursor(n); cursorX += n * step }
            return
        }
        val cur = down
        if (cur?.key?.t == KT.DEL) return
        val k = hit(x, y)
        if (k !== cur) {
            hnd.removeCallbacks(longRun)
            dismissPopup()
            if (k != null && k.key.t == KT.DEL) { down = null; invalidate(); return }
            startKey(k)
        }
    }

    private fun endKey(fire: Boolean) {
        hnd.removeCallbacks(longRun)
        hnd.removeCallbacks(repeatDel)
        val lk = down
        if (altKey != null) {
            if (fire && altSel in alts.indices) {
                afterChar()
                cb.onText(alts[altSel])
            }
        } else if (fire && lk != null && !longDone && !cursorMode) {
            doFire(lk)
        }
        dismissPopup()
        down = null
        altKey = null
        cursorMode = false
        longDone = false
        invalidate()
    }

    private fun afterChar() {
        if (shift == 1) shift = 0
        manual = false
    }

    private fun doFire(lk: LKey) {
        when (lk.key.t) {
            KT.CHAR -> {
                val s = if (shift > 0) lk.key.label.uppercase() else lk.key.label
                afterChar()
                cb.onText(s)
            }
            KT.SHIFT -> {
                val now = SystemClock.uptimeMillis()
                val dbl = now - lastShiftTap < 350
                shift = when { dbl -> 2; shift == 0 -> 1; else -> 0 }
                lastShiftTap = now
                manual = true
            }
            KT.NUM -> setMode(1)
            KT.SYM -> setMode(2)
            KT.ABC -> setMode(0)
            KT.SPACE -> cb.onSpace()
            KT.ENTER -> cb.onEnter()
            KT.EMOJI -> cb.onEmoji()
            else -> {}
        }
    }

    private fun feedback(k: Key) {
        if (p.haptic) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP,
            HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING or HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING)
        if (p.sound) audio.playSoundEffect(when (k.t) {
            KT.DEL -> AudioManager.FX_KEYPRESS_DELETE
            KT.SPACE -> AudioManager.FX_KEYPRESS_SPACEBAR
            KT.ENTER -> AudioManager.FX_KEYPRESS_RETURN
            else -> AudioManager.FX_KEYPRESS_STANDARD
        })
    }

    // ---------------- key preview / accent popup ----------------
    private fun altIndex(x: Float): Int {
        if (popCell <= 0f || alts.isEmpty()) return 0
        val rel = x + locX - popLeft - dp(4f)
        return (rel / popCell).toInt().coerceIn(0, alts.size - 1)
    }

    private fun showBubble(lk: LKey, items: List<String>, multi: Boolean) {
        try {
            val loc = IntArray(2)
            getLocationOnScreen(loc)
            locX = loc[0]
            val sw = resources.displayMetrics.widthPixels.toFloat()
            val kw = lk.r.width()
            val kh = lk.r.height()
            val bh = kh * 1.35f
            val cell = if (multi) minOf(dp(42f), (sw - dp(8f)) / items.size) else 0f
            val bw = if (multi) items.size * cell + dp(8f) else kw + dp(26f)
            val left = (loc[0] + lk.r.centerX() - bw / 2).coerceIn(0f, maxOf(sw - bw, 0f))
            val topY = loc[1] + lk.r.top - bh
            popLeft = left
            popCell = cell
            val b = bubble ?: Bubble().also { bubble = it }
            b.items = items
            b.multi = multi
            b.sel = if (multi) 0 else -1
            b.cell = cell
            b.bubbleH = bh
            b.neckL = (loc[0] + lk.r.left - left).coerceAtLeast(dp(4f))
            b.neckR = (loc[0] + lk.r.right - left).coerceAtMost(bw - dp(4f))
            b.invalidate()
            val w = bw.toInt()
            val h = (bh + kh).toInt()
            val pw = pop
            if (pw != null && pw.isShowing) {
                pw.update(left.toInt(), topY.toInt(), w, h, true)
            } else {
                val np = PopupWindow(b, w, h)
                np.isClippingEnabled = false
                np.isTouchable = false
                np.isFocusable = false
                pop = np
                np.showAtLocation(this, Gravity.NO_GRAVITY, left.toInt(), topY.toInt())
            }
        } catch (e: Exception) {
        }
    }

    private fun dismissPopup() {
        try { pop?.dismiss() } catch (e: Exception) {}
        pop = null
    }

    override fun onDetachedFromWindow() {
        dismissPopup()
        hnd.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }

    private inner class Bubble : View(context) {
        var items: List<String> = emptyList()
        var multi = false
        var sel = -1
        var cell = 0f
        var bubbleH = 0f
        var neckL = 0f
        var neckR = 0f
        private val bp = Paint(Paint.ANTI_ALIAS_FLAG)

        init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val hh = height.toFloat()
            val rad = dp(10f)
            bp.style = Paint.Style.FILL
            bp.color = th.bubble
            bp.setShadowLayer(dp(3f), 0f, dp(1f), 0x66000000)
            c.drawRoundRect(RectF(dp(3f), dp(2f), w - dp(3f), bubbleH), rad, rad, bp)
            c.drawRoundRect(RectF(neckL, bubbleH - rad * 1.5f, neckR, hh - dp(1f)), dp(6f), dp(6f), bp)
            bp.clearShadowLayer()
            bp.typeface = tf
            bp.textAlign = Paint.Align.CENTER
            if (!multi) {
                val s = items.firstOrNull() ?: return
                bp.color = th.text
                bp.textSize = sp(34f)
                val fm = bp.fontMetrics
                c.drawText(s, w / 2, bubbleH / 2 + dp(1f) - (fm.ascent + fm.descent) / 2, bp)
            } else {
                for (i in items.indices) {
                    val l = dp(4f) + i * cell
                    val r = RectF(l + dp(2f), dp(6f), l + cell - dp(2f), bubbleH - dp(4f))
                    if (i == sel) { bp.color = th.accent; c.drawRoundRect(r, dp(8f), dp(8f), bp) }
                    bp.color = if (i == sel) Color.WHITE else th.text
                    bp.textSize = sp(24f)
                    val fm = bp.fontMetrics
                    c.drawText(items[i], r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2, bp)
                }
            }
        }
    }
}
