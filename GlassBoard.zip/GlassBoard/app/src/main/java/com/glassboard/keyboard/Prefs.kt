package com.glassboard.keyboard

import android.content.Context
import android.content.SharedPreferences

class Prefs(ctx: Context) {
    val sp: SharedPreferences =
        ctx.applicationContext.getSharedPreferences("glassboard", Context.MODE_PRIVATE)

    fun i(k: String, d: Int) = sp.getInt(k, d)
    fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    fun s(k: String, d: String) = sp.getString(k, d) ?: d
    fun put(k: String, v: Any) {
        val e = sp.edit()
        when (v) {
            is Int -> e.putInt(k, v)
            is Boolean -> e.putBoolean(k, v)
            is String -> e.putString(k, v)
        }
        e.apply()
    }

    val theme get() = i("theme", 0)            // 0 auto, 1 light, 2 dark
    val style get() = i("style", 0)            // 0 iOS solid, 1 liquid glass
    val accent get() = i("accent", 0xFF007AFF.toInt())
    val keyH get() = i("keyH", 52)             // row height in dp
    val radius get() = i("radius", 6)          // key corner radius dp
    val glass get() = i("glass", 60)           // glass strength 0..100
    val blur get() = i("blur", 50)             // window blur 0..100 (Android 12+)
    val font get() = s("font", "sans-serif")
    val textSize get() = i("textSize", 22)
    val haptic get() = b("haptic", true)
    val sound get() = b("sound", false)
    val preview get() = b("preview", true)
    val numRow get() = b("numRow", false)
    val oneHand get() = i("oneHand", 0)        // 0 off, 1 left, 2 right
    val autoCorrect get() = b("autoCorrect", true)
    val suggest get() = b("suggest", true)
    val autoCap get() = b("autoCap", true)
    val dblSpace get() = b("dblSpace", true)
    val bgImage get() = s("bgImage", "")
    val tone get() = i("tone", 0)
    val recents get() = s("recents", "")
}
