package com.glassboard.keyboard

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Clip(val id: Long, val text: String, val pinned: Boolean)

class Db(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "glassboard.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE clips(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT UNIQUE, pinned INTEGER DEFAULT 0, ts INTEGER)")
        db.execSQL("CREATE TABLE words(w TEXT PRIMARY KEY, c INTEGER)")
        db.execSQL("CREATE TABLE bigrams(a TEXT, b TEXT, c INTEGER, PRIMARY KEY(a,b))")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    // ---- clipboard (unlimited history) ----
    fun addClip(t: String) {
        val now = System.currentTimeMillis()
        val db = writableDatabase
        db.execSQL("INSERT OR IGNORE INTO clips(text,pinned,ts) VALUES(?,0,?)", arrayOf<Any>(t, now))
        db.execSQL("UPDATE clips SET ts=? WHERE text=?", arrayOf<Any>(now, t))
    }

    fun clips(q: String): List<Clip> {
        val out = ArrayList<Clip>()
        val c = readableDatabase.rawQuery(
            "SELECT id, substr(text,1,300), pinned FROM clips WHERE text LIKE ? ORDER BY pinned DESC, ts DESC",
            arrayOf("%$q%")
        )
        c.use { while (it.moveToNext()) out.add(Clip(it.getLong(0), it.getString(1), it.getInt(2) == 1)) }
        return out
    }

    fun clipText(id: Long): String {
        val c = readableDatabase.rawQuery("SELECT text FROM clips WHERE id=?", arrayOf(id.toString()))
        return c.use { if (it.moveToFirst()) it.getString(0) else "" }
    }

    fun pin(id: Long, v: Boolean) {
        writableDatabase.execSQL("UPDATE clips SET pinned=? WHERE id=?", arrayOf<Any>(if (v) 1 else 0, id))
    }

    fun del(id: Long) {
        writableDatabase.execSQL("DELETE FROM clips WHERE id=?", arrayOf<Any>(id))
    }

    fun clearUnpinned() {
        writableDatabase.execSQL("DELETE FROM clips WHERE pinned=0")
    }

    // ---- learning ----
    fun clearLearned() {
        writableDatabase.execSQL("DELETE FROM words")
        writableDatabase.execSQL("DELETE FROM bigrams")
    }

    fun loadWords(): HashMap<String, Int> {
        val m = HashMap<String, Int>()
        val c = readableDatabase.rawQuery("SELECT w,c FROM words", null)
        c.use { while (it.moveToNext()) m[it.getString(0)] = it.getInt(1) }
        return m
    }

    fun loadBigrams(): HashMap<String, HashMap<String, Int>> {
        val m = HashMap<String, HashMap<String, Int>>()
        val c = readableDatabase.rawQuery("SELECT a,b,c FROM bigrams", null)
        c.use { while (it.moveToNext()) m.getOrPut(it.getString(0)) { HashMap() }[it.getString(1)] = it.getInt(2) }
        return m
    }

    fun bump(w: String, n: Int) {
        val db = writableDatabase
        db.execSQL("INSERT OR IGNORE INTO words(w,c) VALUES(?,0)", arrayOf<Any>(w))
        db.execSQL("UPDATE words SET c=c+? WHERE w=?", arrayOf<Any>(n, w))
    }

    fun bumpBi(a: String, b: String) {
        val db = writableDatabase
        db.execSQL("INSERT OR IGNORE INTO bigrams(a,b,c) VALUES(?,?,0)", arrayOf<Any>(a, b))
        db.execSQL("UPDATE bigrams SET c=c+1 WHERE a=? AND b=?", arrayOf<Any>(a, b))
    }
}
