package com.glassboard.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.SparseArray
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import kotlin.math.max
import kotlin.math.min

enum class Layer { LETTERS, NUMBERS, SYMBOLS }

enum class EnterKind { RETURN, SEARCH, GO, SEND, NEXT, DONE }

private enum class KeyType { CHAR, SHIFT, DEL, MODE_NUM, MODE_SYM, MODE_ABC, SPACE, ENTER }

private class Key(val type: KeyType, val label: String) {
    val rect = RectF()
}

private class Pointer(var key: Key?, val slot: Int)

/**
 * Single custom view that draws the whole keyboard (suggestion strip + keys) in an
 * iOS-like style. The blurred, rounded-top panel itself is the IME window background
 * (see KeyboardService.applyWindowStyle); this view only draws translucent keys on top.
 */
class KeyboardView(context: Context) : View(context) {

    interface Listener {
        fun onChar(text: String)
        fun onDelete()
        fun onShift()
        fun onSpace()
        fun onEnter()
        fun onSuggestion(index: Int)
    }

    var listener: Listener? = null

    /** Up to three strings shown in the suggestion strip. */
    var suggestions: List<String> = emptyList()
        set(value) {
            field = value
            invalidate()
        }

    var enterKind: EnterKind = EnterKind.RETURN
        set(value) {
            field = value
            invalidate()
        }

    private var layer = Layer.LETTERS
    private var shiftState = 0 // 0 = off, 1 = once, 2 = caps lock
    private var bottomInset = 0
    private var keys: List<Key> = emptyList()

    // Metrics, all derived from the view width so the proportions match the reference keyboard.
    private var margin = 0f
    private var hGap = 0f
    private var vGap = 0f
    private var keyH = 0f
    private var radius = 0f
    private var stripH = 0f
    private var bottomPad = 0f

    private val keyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Color.WHITE
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 255, 255, 255)
        strokeWidth = 1f * resources.displayMetrics.density
    }
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glossPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }
    private var fillShader: Shader? = null
    private var rimShader: Shader? = null
    private val density = resources.displayMetrics.density
    private val path = Path()
    private val bubbleRect = RectF()
    private val glassRect = RectF()

    private val pointers = SparseArray<Pointer>()
    private val handler = Handler(Looper.getMainLooper())
    private var repeatPointerId = -1
    private val repeatRunnable = object : Runnable {
        override fun run() {
            listener?.onDelete()
            handler.postDelayed(this, 45)
        }
    }

    // ---------------------------------------------------------------- public API

    fun setLayer(newLayer: Layer) {
        if (layer == newLayer) return
        layer = newLayer
        pointers.clear()
        stopRepeat()
        buildKeys()
        invalidate()
    }

    fun setShift(state: Int) {
        if (shiftState == state) return
        shiftState = state
        invalidate()
    }

    // ---------------------------------------------------------------- layout

    private fun updateMetrics(w: Float) {
        margin = w * 0.0215f
        hGap = w * 0.0149f
        vGap = w * 0.0282f
        keyH = w * 0.1111f
        radius = w * 0.0182f
        stripH = w * 0.12f
        // Samsung draws its keyboard-switch and hide buttons in the bottom ~24dp of the screen,
        // so always keep at least 28dp free under the last row, even if no inset is reported.
        bottomPad = w * 0.035f + max(bottomInset.toFloat(), 28f * density)
        // Shared vertical gradients for the glass look (keys are drawn translated to y = 0).
        fillShader = LinearGradient(
            0f, 0f, 0f, keyH,
            Color.argb(255, 255, 255, 255), Color.argb(150, 255, 255, 255), Shader.TileMode.CLAMP
        )
        rimShader = LinearGradient(
            0f, 0f, 0f, keyH,
            Color.argb(255, 255, 255, 255), Color.argb(50, 255, 255, 255), Shader.TileMode.CLAMP
        )
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        var w = MeasureSpec.getSize(widthMeasureSpec)
        if (w <= 0) w = resources.displayMetrics.widthPixels
        updateMetrics(w.toFloat())
        val h = stripH + 4 * keyH + 3 * vGap + bottomPad
        setMeasuredDimension(w, h.toInt())
        buildKeys()
    }

    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        val b = insets.getInsets(WindowInsets.Type.navigationBars()).bottom
        if (b != bottomInset) {
            bottomInset = b
            requestLayout()
        }
        return insets
    }

    private fun buildKeys() {
        val w = measuredWidth.toFloat()
        if (w <= 0f) return
        val list = ArrayList<Key>()
        val avail = w - 2 * margin
        val u = (avail - 9 * hGap) / 10f
        fun rowTop(i: Int) = stripH + i * (keyH + vGap)

        fun add(type: KeyType, label: String, left: Float, top: Float, right: Float) {
            val k = Key(type, label)
            k.rect.set(left, top, right, top + keyH)
            list.add(k)
        }

        fun charRow(chars: String, startX: Float, keyW: Float, top: Float) {
            for (i in chars.indices) {
                val x = startX + i * (keyW + hGap)
                add(KeyType.CHAR, chars[i].toString(), x, top, x + keyW)
            }
        }

        val sideW = 2.77f * u
        val wideW = 1.35f * u

        when (layer) {
            Layer.LETTERS -> {
                charRow("qwertyuiop", margin, u, rowTop(0))
                charRow("asdfghjkl", margin + (u + hGap) / 2f, u, rowTop(1))
                val gap3 = (avail - 2 * wideW - 7 * u - 6 * hGap) / 2f
                add(KeyType.SHIFT, "", margin, rowTop(2), margin + wideW)
                charRow("zxcvbnm", margin + wideW + gap3, u, rowTop(2))
                add(KeyType.DEL, "", w - margin - wideW, rowTop(2), w - margin)
            }
            Layer.NUMBERS, Layer.SYMBOLS -> {
                val numbers = layer == Layer.NUMBERS
                charRow(if (numbers) "1234567890" else "[]{}#%^*+=", margin, u, rowTop(0))
                charRow(if (numbers) "-/:;()$&@\"" else "_\\|~<>€£₹•", margin, u, rowTop(1))
                val kw = (avail - 2 * wideW - 6 * hGap) / 5f
                add(
                    if (numbers) KeyType.MODE_SYM else KeyType.MODE_NUM,
                    if (numbers) "#+=" else "123",
                    margin, rowTop(2), margin + wideW
                )
                charRow(".,?!'", margin + wideW + hGap, kw, rowTop(2))
                add(KeyType.DEL, "", w - margin - wideW, rowTop(2), w - margin)
            }
        }

        // Bottom row: mode key, space, action key.
        val t3 = rowTop(3)
        if (layer == Layer.LETTERS) {
            add(KeyType.MODE_NUM, "123", margin, t3, margin + sideW)
        } else {
            add(KeyType.MODE_ABC, "ABC", margin, t3, margin + sideW)
        }
        add(KeyType.SPACE, "", margin + sideW + hGap, t3, w - margin - sideW - hGap)
        add(KeyType.ENTER, "", w - margin - sideW, t3, w - margin)

        keys = list
    }

    // ---------------------------------------------------------------- drawing

    override fun onDraw(canvas: Canvas) {
        drawSuggestions(canvas)

        val pressed = HashSet<Key>()
        for (i in 0 until pointers.size()) pointers.valueAt(i).key?.let { pressed.add(it) }

        for (k in keys) drawKey(canvas, k, pressed.contains(k))

        for (k in pressed) {
            if (k.type == KeyType.CHAR) drawBubble(canvas, k)
        }
    }

    private fun drawSuggestions(c: Canvas) {
        val slotW = width / 3f
        textPaint.textSize = stripH * 0.30f
        val fm = textPaint.fontMetrics
        val baseline = stripH / 2f - (fm.ascent + fm.descent) / 2f
        val count = min(3, suggestions.size)
        for (i in 0 until count) {
            val text = TextUtils.ellipsize(
                suggestions[i], android.text.TextPaint(textPaint), slotW - 24f, TextUtils.TruncateAt.END
            ).toString()
            c.drawText(text, slotW * i + slotW / 2f, baseline, textPaint)
        }
        if (count > 0) {
            val top = stripH * 0.25f
            val bottom = stripH * 0.75f
            c.drawLine(slotW, top, slotW, bottom, linePaint)
            c.drawLine(slotW * 2, top, slotW * 2, bottom, linePaint)
        }
    }

    private fun drawKey(c: Canvas, k: Key, pressed: Boolean) {
        val shiftOn = k.type == KeyType.SHIFT && shiftState != 0
        val alpha = when (k.type) {
            KeyType.CHAR -> if (pressed) 0.40f else 0.22f
            KeyType.SPACE -> if (pressed) 0.32f else 0.17f
            KeyType.ENTER -> if (pressed) 0.55f else 0.40f
            else -> if (pressed) 0.32f else 0.16f
        }
        // Liquid-glass key: translucent gradient fill, bright rim fading downwards, thin top gloss.
        c.save()
        c.translate(0f, k.rect.top)
        glassRect.set(k.rect.left, 0f, k.rect.right, keyH)
        if (shiftOn) {
            keyPaint.shader = null
            keyPaint.color = Color.argb(235, 255, 255, 255)
        } else {
            keyPaint.shader = fillShader
            keyPaint.color = Color.WHITE
            keyPaint.alpha = (alpha * 1.35f * 255).toInt().coerceIn(0, 255)
        }
        c.drawRoundRect(glassRect, radius, radius, keyPaint)
        keyPaint.shader = null

        val rimW = 1.2f * density
        rimPaint.strokeWidth = rimW
        rimPaint.shader = rimShader
        rimPaint.color = Color.WHITE
        rimPaint.alpha = if (pressed) 200 else 120
        glassRect.inset(rimW / 2f, rimW / 2f)
        c.drawRoundRect(glassRect, radius, radius, rimPaint)
        rimPaint.shader = null

        glossPaint.strokeWidth = 1f * density
        glossPaint.alpha = if (shiftOn) 0 else 70
        c.drawLine(
            k.rect.left + radius * 0.9f, 2.2f * density,
            k.rect.right - radius * 0.9f, 2.2f * density, glossPaint
        )
        c.restore()

        val fg = if (shiftOn) Color.rgb(28, 28, 30) else Color.WHITE
        when (k.type) {
            KeyType.CHAR -> {
                val text = if (layer == Layer.LETTERS && shiftState != 0) k.label.uppercase() else k.label
                drawLabel(c, text, k.rect, keyH * 0.40f, Color.WHITE)
            }
            KeyType.MODE_NUM, KeyType.MODE_SYM, KeyType.MODE_ABC ->
                drawLabel(c, k.label, k.rect, keyH * 0.33f, Color.WHITE)
            KeyType.SHIFT -> drawShiftIcon(c, k.rect, fg, shiftOn, shiftState == 2)
            KeyType.DEL -> drawDeleteIcon(c, k.rect)
            KeyType.ENTER -> when (enterKind) {
                EnterKind.SEARCH -> drawSearchIcon(c, k.rect)
                EnterKind.RETURN -> drawLabel(c, "return", k.rect, keyH * 0.30f, Color.WHITE)
                EnterKind.GO -> drawLabel(c, "go", k.rect, keyH * 0.33f, Color.WHITE)
                EnterKind.SEND -> drawLabel(c, "send", k.rect, keyH * 0.33f, Color.WHITE)
                EnterKind.NEXT -> drawLabel(c, "next", k.rect, keyH * 0.33f, Color.WHITE)
                EnterKind.DONE -> drawLabel(c, "done", k.rect, keyH * 0.33f, Color.WHITE)
            }
            KeyType.SPACE -> Unit
        }
    }

    private fun drawLabel(c: Canvas, text: String, r: RectF, size: Float, color: Int) {
        textPaint.textSize = size
        textPaint.color = color
        val fm = textPaint.fontMetrics
        c.drawText(text, r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2f, textPaint)
        textPaint.color = Color.WHITE
    }

    private fun drawBubble(c: Canvas, k: Key) {
        val text = if (layer == Layer.LETTERS && shiftState != 0) k.label.uppercase() else k.label
        val bw = k.rect.width() * 1.45f
        val bh = keyH * 1.05f
        var left = k.rect.centerX() - bw / 2f
        left = max(4f, min(width - bw - 4f, left))
        val bottom = k.rect.top + keyH * 0.12f
        val top = max(2f, bottom - bh)
        bubbleRect.set(left, top, left + bw, top + bh)
        keyPaint.color = Color.rgb(88, 88, 92)
        c.drawRoundRect(bubbleRect, radius * 1.4f, radius * 1.4f, keyPaint)
        rimPaint.shader = null
        rimPaint.strokeWidth = 1.2f * density
        rimPaint.color = Color.argb(110, 255, 255, 255)
        c.drawRoundRect(bubbleRect, radius * 1.4f, radius * 1.4f, rimPaint)
        drawLabel(c, text, bubbleRect, keyH * 0.62f, Color.WHITE)
    }

    private fun drawShiftIcon(c: Canvas, r: RectF, color: Int, filled: Boolean, lock: Boolean) {
        val s = keyH * 0.40f
        val cx = r.centerX()
        val cy = r.centerY() - (if (lock) s * 0.06f else 0f)
        path.reset()
        path.moveTo(cx, cy - s * 0.55f)
        path.lineTo(cx + s * 0.55f, cy + s * 0.02f)
        path.lineTo(cx + s * 0.22f, cy + s * 0.02f)
        path.lineTo(cx + s * 0.22f, cy + s * 0.50f)
        path.lineTo(cx - s * 0.22f, cy + s * 0.50f)
        path.lineTo(cx - s * 0.22f, cy + s * 0.02f)
        path.lineTo(cx - s * 0.55f, cy + s * 0.02f)
        path.close()
        iconPaint.color = color
        iconPaint.strokeWidth = s * 0.11f
        iconPaint.style = if (filled) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
        c.drawPath(path, iconPaint)
        if (lock) c.drawLine(cx - s * 0.22f, cy + s * 0.72f, cx + s * 0.22f, cy + s * 0.72f, iconPaint)
        iconPaint.style = Paint.Style.STROKE
    }

    private fun drawDeleteIcon(c: Canvas, r: RectF) {
        val s = keyH * 0.42f
        val cx = r.centerX()
        val cy = r.centerY()
        path.reset()
        path.moveTo(cx - s * 0.62f, cy)
        path.lineTo(cx - s * 0.25f, cy - s * 0.45f)
        path.lineTo(cx + s * 0.62f, cy - s * 0.45f)
        path.lineTo(cx + s * 0.62f, cy + s * 0.45f)
        path.lineTo(cx - s * 0.25f, cy + s * 0.45f)
        path.close()
        iconPaint.color = Color.WHITE
        iconPaint.strokeWidth = s * 0.10f
        c.drawPath(path, iconPaint)
        c.drawLine(cx - s * 0.05f, cy - s * 0.17f, cx + s * 0.35f, cy + s * 0.17f, iconPaint)
        c.drawLine(cx + s * 0.35f, cy - s * 0.17f, cx - s * 0.05f, cy + s * 0.17f, iconPaint)
    }

    private fun drawSearchIcon(c: Canvas, r: RectF) {
        val s = keyH * 0.40f
        val cx = r.centerX()
        val cy = r.centerY()
        iconPaint.color = Color.WHITE
        iconPaint.strokeWidth = s * 0.13f
        c.drawCircle(cx - s * 0.10f, cy - s * 0.10f, s * 0.30f, iconPaint)
        c.drawLine(cx + s * 0.13f, cy + s * 0.13f, cx + s * 0.50f, cy + s * 0.50f, iconPaint)
    }

    // ---------------------------------------------------------------- touch

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                onDown(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) onMove(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                onUp(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_CANCEL -> {
                pointers.clear()
                stopRepeat()
                invalidate()
            }
        }
        return true
    }

    private fun slotOf(x: Float): Int = min(2, max(0, (x / (width / 3f)).toInt()))

    private fun hit(x: Float, y: Float): Key? {
        var best: Key? = null
        var bestD = Float.MAX_VALUE
        for (k in keys) {
            val dx = max(max(k.rect.left - x, x - k.rect.right), 0f)
            val dy = max(max(k.rect.top - y, y - k.rect.bottom), 0f)
            val d = dx * dx + dy * dy
            if (d < bestD) {
                bestD = d
                best = k
            }
        }
        return best
    }

    private fun onDown(id: Int, x: Float, y: Float) {
        if (y < stripH) {
            pointers.put(id, Pointer(null, slotOf(x)))
            return
        }
        val k = hit(x, y) ?: return
        pointers.put(id, Pointer(k, -1))
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        if (k.type == KeyType.DEL) {
            listener?.onDelete()
            stopRepeat()
            repeatPointerId = id
            handler.postDelayed(repeatRunnable, 400)
        }
        invalidate()
    }

    private fun onMove(id: Int, x: Float, y: Float) {
        val p = pointers.get(id) ?: return
        val current = p.key ?: return
        if (current.type == KeyType.DEL) return
        val k = hit(x, y) ?: return
        if (k !== current) {
            p.key = k
            invalidate()
        }
    }

    private fun onUp(id: Int, x: Float, y: Float) {
        val p = pointers.get(id) ?: return
        pointers.remove(id)
        if (p.slot >= 0) {
            if (y < stripH && slotOf(x) == p.slot) listener?.onSuggestion(p.slot)
        } else {
            val k = p.key
            if (k != null) {
                if (k.type == KeyType.DEL) {
                    if (repeatPointerId == id) stopRepeat()
                } else {
                    activate(k)
                }
            }
        }
        invalidate()
    }

    private fun stopRepeat() {
        handler.removeCallbacks(repeatRunnable)
        repeatPointerId = -1
    }

    private fun activate(k: Key) {
        when (k.type) {
            KeyType.CHAR -> listener?.onChar(
                if (layer == Layer.LETTERS && shiftState != 0) k.label.uppercase() else k.label
            )
            KeyType.SHIFT -> listener?.onShift()
            KeyType.SPACE -> listener?.onSpace()
            KeyType.ENTER -> listener?.onEnter()
            KeyType.MODE_NUM -> setLayer(Layer.NUMBERS)
            KeyType.MODE_SYM -> setLayer(Layer.SYMBOLS)
            KeyType.MODE_ABC -> setLayer(Layer.LETTERS)
            KeyType.DEL -> Unit
        }
    }

    override fun onDetachedFromWindow() {
        stopRepeat()
        super.onDetachedFromWindow()
    }
}
