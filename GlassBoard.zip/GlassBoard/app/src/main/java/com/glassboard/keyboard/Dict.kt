package com.glassboard.keyboard

import android.content.Context
import java.util.concurrent.Executors
import kotlin.math.abs

fun applyCase(src: String, cand: String): String = when {
    src.isEmpty() -> cand
    src.length > 1 && src.all { it.isUpperCase() } -> cand.uppercase()
    src[0].isUpperCase() -> cand.replaceFirstChar { it.uppercase() }
    else -> cand
}

/** English (India) + Tinglish dictionary with on-device learning. */
class Dict(ctx: Context, private val db: Db) {
    private val list = ArrayList<String>()
    private val score = HashMap<String, Float>()
    private val learned: HashMap<String, Int> = db.loadWords()
    private val bi: HashMap<String, HashMap<String, Int>> = db.loadBigrams()
    private val io = Executors.newSingleThreadExecutor()

    private val shortcuts = mapOf(
        "i" to "I", "im" to "I'm", "ive" to "I've", "dont" to "don't", "cant" to "can't",
        "wont" to "won't", "didnt" to "didn't", "doesnt" to "doesn't", "isnt" to "isn't",
        "wasnt" to "wasn't", "couldnt" to "couldn't", "wouldnt" to "wouldn't",
        "shouldnt" to "shouldn't", "youre" to "you're", "thats" to "that's", "whats" to "what's",
        "havent" to "haven't", "hasnt" to "hasn't", "arent" to "aren't", "theyre" to "they're"
    )

    init {
        // Word files are ordered most-frequent first. Replace/extend them in app/src/main/assets.
        for (f in listOf("dict_en.txt", "dict_tinglish.txt")) {
            try {
                val words = ctx.assets.open(f).bufferedReader().readText()
                    .split(Regex("\\s+")).filter { it.isNotEmpty() }.map { it.lowercase() }.distinct()
                words.forEachIndexed { i, w ->
                    if (!score.containsKey(w)) {
                        score[w] = 1f - 0.8f * i / words.size
                        list.add(w)
                    }
                }
            } catch (e: Exception) {
            }
        }
    }

    private fun rk(w: String) = (score[w] ?: 0.3f) + minOf(learned[w] ?: 0, 20) * 0.08f

    fun known(w: String): Boolean {
        if (score.containsKey(w) || (learned[w] ?: 0) >= 2) return true
        for (s in arrayOf("s", "es", "ed", "d", "ing", "ly", "er", "ers", "'s", "ies")) {
            if (w.length > s.length + 2 && w.endsWith(s)) {
                val st = w.dropLast(s.length)
                if (score.containsKey(st)) return true
                if (st.length > 2 && st[st.length - 1] == st[st.length - 2] && score.containsKey(st.dropLast(1))) return true
                if (score.containsKey(st + "e")) return true
            }
        }
        return false
    }

    private fun dist(a: String, b: String): Int {
        val n = a.length
        val m = b.length
        val d = Array(n + 1) { IntArray(m + 1) }
        for (i in 0..n) d[i][0] = i
        for (j in 0..m) d[0][j] = j
        for (i in 1..n) for (j in 1..m) {
            val c = if (a[i - 1] == b[j - 1]) 0 else 1
            var v = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + c)
            if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) v = minOf(v, d[i - 2][j - 2] + 1)
            d[i][j] = v
        }
        return d[n][m]
    }

    fun complete(pre: String, limit: Int): List<String> {
        val out = ArrayList<String>()
        val pool = ArrayList<String>(list.size + learned.size)
        pool.addAll(list)
        for (k in learned.keys) if (!score.containsKey(k)) pool.add(k)
        pool.filter { it.length > pre.length && it.startsWith(pre) }
            .sortedByDescending { rk(it) }.take(limit).forEach { out.add(it) }
        if (out.size < limit && pre.length >= 2) {
            val maxD = if (pre.length <= 4) 1 else 2
            val near = pool.filter { abs(it.length - pre.length) <= maxD && it != pre }
                .map { it to dist(pre, it) }.filter { it.second <= maxD }
                .sortedWith(compareBy<Pair<String, Int>>({ it.second }, { -rk(it.first) }))
            for ((w, _) in near) if (w !in out && out.size < limit) out.add(w)
        }
        return out
    }

    /** Returns the autocorrected word, or null if the word should be left alone. */
    fun fix(w: String): String? {
        val lw = w.lowercase()
        shortcuts[lw]?.let { return if (lw == "i") it else applyCase(w, it) }
        if (w.length < 3) return null
        if (w.any { it.isDigit() }) return null
        if (w.drop(1).any { it.isUpperCase() }) return null
        if (w[0].isUpperCase()) return null          // likely a name
        if (known(lw)) return null
        val maxD = if (lw.length >= 7) 2 else 1
        var best: String? = null
        var bd = 99
        var br = -1f
        for (c in list) {
            if (c[0] != lw[0] || abs(c.length - lw.length) > maxD) continue
            val d = dist(lw, c)
            if (d > maxD) continue
            val r = rk(c)
            if (d < bd || (d == bd && r > br)) { best = c; bd = d; br = r }
        }
        return best?.let { applyCase(w, it) }
    }

    fun learn(prev: String?, w: String) {
        if (w.length < 2 || !w.all { it.isLetter() || it == '\'' }) return
        learned[w] = (learned[w] ?: 0) + 1
        io.execute { db.bump(w, 1) }
        if (prev != null) {
            val m = bi.getOrPut(prev) { HashMap() }
            m[w] = (m[w] ?: 0) + 1
            io.execute { db.bumpBi(prev, w) }
        }
    }

    fun boost(w: String) {
        learned[w] = (learned[w] ?: 0) + 3
        io.execute { db.bump(w, 3) }
    }

    fun next(prev: String?): List<String> {
        val out = ArrayList<String>()
        if (prev != null) {
            bi[prev]?.entries?.sortedByDescending { it.value }?.forEach {
                if (out.size < 3) out.add(if (it.key == "i") "I" else it.key)
            }
        }
        for (d in listOf("I", "the", "to", "and", "you")) if (out.size < 3 && d !in out) out.add(d)
        return out
    }
}
