package com.glassboard.keyboard

import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.SystemClock
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import java.util.function.Consumer

class KeyboardService : InputMethodService(), KeyboardView.Listener {

    private var keyboard: KeyboardView? = null
    private val dictionary = WordDictionary()

    private val composing = StringBuilder()
    private var suggestionsOn = false
    private var autoCap = false
    private var commits: List<String> = emptyList()

    private var shiftState = 0 // 0 = off, 1 = once, 2 = caps lock
    private var lastShiftTap = 0L
    private var lastSpaceTime = 0L

    private val blurListener = Consumer<Boolean> { applyWindowStyle() }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate() {
        setTheme(R.style.KeyboardTheme) // must run before super.onCreate()
        super.onCreate()
        dictionary.load(this)
        applyWindowStyle()
        getSystemService(WindowManager::class.java)
            ?.addCrossWindowBlurEnabledListener(mainExecutor, blurListener)
    }

    override fun onDestroy() {
        getSystemService(WindowManager::class.java)
            ?.removeCrossWindowBlurEnabledListener(blurListener)
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        val v = KeyboardView(this)
        v.listener = this
        keyboard = v
        return v
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        composing.setLength(0)

        val type = info.inputType
        val cls = type and InputType.TYPE_MASK_CLASS
        val variation = type and InputType.TYPE_MASK_VARIATION
        val noSuggestions = (type and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0
        val isText = cls == InputType.TYPE_CLASS_TEXT
        val blocked = variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_URI
        suggestionsOn = isText && !noSuggestions && !blocked
        autoCap = isText

        val kb = keyboard
        if (kb != null) {
            val numeric = cls == InputType.TYPE_CLASS_NUMBER ||
                cls == InputType.TYPE_CLASS_PHONE ||
                cls == InputType.TYPE_CLASS_DATETIME
            kb.setLayer(if (numeric) Layer.NUMBERS else Layer.LETTERS)
            kb.enterKind = enterKindFor(info)
        }
        applyWindowStyle()
        shiftState = 0
        refreshShift()
        updateSuggestions()
    }

    override fun onFinishInput() {
        composing.setLength(0)
        commits = emptyList()
        super.onFinishInput()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int,
        newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(
            oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd
        )
        // Cursor moved by the user (not by us): forget the word being composed.
        if (composing.isNotEmpty() && (newSelStart != candidatesEnd || newSelEnd != candidatesEnd)) {
            composing.setLength(0)
            currentInputConnection?.finishComposingText()
            updateSuggestions()
        }
    }

    // ------------------------------------------------------------ window: blur + rounded top corners

    private fun applyWindowStyle() {
        val w = window?.window ?: return
        val blurOn = getSystemService(WindowManager::class.java)?.isCrossWindowBlurEnabled == true
        val r = resources.displayMetrics.widthPixels * 0.045f
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            // Rounded top corners only, like the reference keyboard.
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            // Glass tint: lighter at the top, darker at the bottom; nearly solid if blur is off.
            orientation = GradientDrawable.Orientation.TOP_BOTTOM
            colors = if (blurOn) {
                intArrayOf(Color.argb(115, 80, 80, 86), Color.argb(150, 14, 14, 16))
            } else {
                intArrayOf(Color.argb(246, 44, 44, 46), Color.argb(250, 20, 20, 22))
            }
            // Bright glass edge along the rounded top.
            setStroke((1.2f * resources.displayMetrics.density).toInt().coerceAtLeast(1),
                Color.argb(if (blurOn) 95 else 40, 255, 255, 255))
        }
        w.setFormat(PixelFormat.TRANSLUCENT)
        w.setBackgroundDrawable(bg)
        w.setBackgroundBlurRadius(if (blurOn) 100 else 0)
    }

    // ------------------------------------------------------------ typing

    override fun onChar(text: String) {
        val ic = currentInputConnection ?: return
        val isWordChar = text.length == 1 &&
            (text[0].isLetter() || (text[0] == '\'' && composing.isNotEmpty()))
        if (suggestionsOn && isWordChar) {
            composing.append(text)
            ic.setComposingText(composing, 1)
        } else {
            finishComposing(ic)
            ic.commitText(text, 1)
        }
        if (shiftState == 1) {
            shiftState = 0
            keyboard?.setShift(0)
        }
        refreshShift()
        updateSuggestions()
    }

    override fun onDelete() {
        val ic = currentInputConnection ?: return
        if (composing.isNotEmpty()) {
            composing.deleteCharAt(composing.length - 1)
            if (composing.isEmpty()) ic.commitText("", 1) else ic.setComposingText(composing, 1)
        } else {
            val selected = ic.getSelectedText(0)
            if (!selected.isNullOrEmpty()) {
                ic.commitText("", 1)
            } else {
                val before = ic.getTextBeforeCursor(2, 0)
                if (before.isNullOrEmpty()) {
                    sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
                } else {
                    val n = if (before.length == 2 &&
                        Character.isHighSurrogate(before[0]) && Character.isLowSurrogate(before[1])
                    ) 2 else 1
                    ic.deleteSurroundingText(n, 0)
                }
            }
        }
        refreshShift()
        updateSuggestions()
    }

    override fun onSpace() {
        val ic = currentInputConnection ?: return
        finishComposing(ic)
        val now = SystemClock.uptimeMillis()
        var periodAdded = false
        if (suggestionsOn && now - lastSpaceTime < 450) {
            // Double space becomes ". " after a word.
            val before = ic.getTextBeforeCursor(2, 0)
            if (before != null && before.length == 2 && before[1] == ' ' &&
                (before[0].isLetterOrDigit() || before[0] == ')' || before[0] == '"')
            ) {
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                periodAdded = true
            }
        }
        if (!periodAdded) ic.commitText(" ", 1)
        lastSpaceTime = if (periodAdded) 0L else now
        refreshShift()
        updateSuggestions()
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        finishComposing(ic)
        val info = currentInputEditorInfo
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (info == null || noAction ||
            action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        } else {
            ic.performEditorAction(action)
        }
        refreshShift()
        updateSuggestions()
    }

    override fun onShift() {
        val now = SystemClock.uptimeMillis()
        shiftState = when {
            shiftState == 2 -> 0
            shiftState == 1 && now - lastShiftTap < 350 -> 2 // double tap = caps lock
            shiftState == 1 -> 0
            else -> 1
        }
        lastShiftTap = now
        keyboard?.setShift(shiftState)
    }

    override fun onSuggestion(index: Int) {
        val ic = currentInputConnection ?: return
        val word = commits.getOrNull(index) ?: return
        ic.commitText("$word ", 1)
        composing.setLength(0)
        lastSpaceTime = 0L
        refreshShift()
        updateSuggestions()
    }

    // ------------------------------------------------------------ helpers

    private fun finishComposing(ic: android.view.inputmethod.InputConnection) {
        if (composing.isNotEmpty()) {
            composing.setLength(0)
            ic.finishComposingText()
        }
    }

    /** Capitalise automatically at the start of a sentence unless caps lock is on. */
    private fun refreshShift() {
        if (shiftState == 2) return
        val info = currentInputEditorInfo
        val caps = if (autoCap && info != null) {
            currentInputConnection?.getCursorCapsMode(info.inputType) ?: 0
        } else 0
        shiftState = if (caps != 0) 1 else 0
        keyboard?.setShift(shiftState)
    }

    private fun updateSuggestions() {
        val kb = keyboard ?: return
        if (!suggestionsOn || composing.isEmpty()) {
            commits = emptyList()
            kb.suggestions = emptyList()
            return
        }
        val typed = composing.toString()
        val found = dictionary.suggest(typed, 2).map { matchCase(typed, it) }
        // Left: what you typed (in quotes), centre: best guess, right: second guess.
        val shown = ArrayList<String>()
        val picks = ArrayList<String>()
        shown.add("“$typed”")
        picks.add(typed)
        for (w in found) {
            shown.add(w)
            picks.add(w)
        }
        commits = picks
        kb.suggestions = shown
    }

    private fun matchCase(typed: String, word: String): String {
        val letters = typed.filter { it.isLetter() }
        return when {
            letters.length > 1 && letters.all { it.isUpperCase() } -> word.uppercase()
            typed.isNotEmpty() && typed[0].isUpperCase() ->
                word.replaceFirstChar { it.uppercase() }
            else -> word
        }
    }

    private fun enterKindFor(info: EditorInfo): EnterKind {
        if ((info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return EnterKind.RETURN
        return when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_SEARCH -> EnterKind.SEARCH
            EditorInfo.IME_ACTION_GO -> EnterKind.GO
            EditorInfo.IME_ACTION_SEND -> EnterKind.SEND
            EditorInfo.IME_ACTION_NEXT -> EnterKind.NEXT
            EditorInfo.IME_ACTION_DONE -> EnterKind.DONE
            else -> EnterKind.RETURN
        }
    }
}
