package com.glassboard.keyboard

import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs

class KeyboardService : InputMethodService(), KeyboardView.Callback {
    private class Sug(val text: String, val literal: Boolean)

    private lateinit var p: Prefs
    private lateinit var db: Db
    private lateinit var dict: Dict
    private lateinit var th: Th
    private lateinit var kbd: KeyboardView
    private lateinit var root: LinearLayout
    private lateinit var sugRow: LinearLayout
    private lateinit var panelRow: LinearLayout
    private lateinit var searchTv: TextView
    private lateinit var searchX: TextView
    private lateinit var clearTv: TextView
    private lateinit var panelFrame: FrameLayout
    private lateinit var emojiGrid: GridView
    private lateinit var clipList: ListView
    private lateinit var emptyTv: TextView
    private lateinit var bottomBar: LinearLayout
    private lateinit var catScroll: HorizontalScrollView
    private lateinit var btnTone: TextView
    private lateinit var spacer: View
    private val sugs = ArrayList<TextView>()
    private val catViews = ArrayList<TextView>()
    private val sugData = arrayOfNulls<Sug>(3)
    private val emojiAdapter = EmojiAdapter()
    private val clipAdapter = ClipAdapter()
    private val io = Executors.newSingleThreadExecutor()
    private val hnd = Handler(Looper.getMainLooper())

    private var mode = 0            // 0 typing, 1 emoji, 2 clipboard
    private var searching = false
    private var query = ""
    private var cat = 1
    private var smart = true        // autocorrect/suggestions allowed in this field
    private var lastFix: Pair<String, String>? = null
    private var lastClip = ""
    private var bgBmp: Bitmap? = null
    private var bgStamp = -1L

    // ------------------------------------------------------------ lifecycle
    override fun onCreate() {
        super.onCreate()
        p = Prefs(this)
        db = Db(this)
        dict = Dict(this, db)
        th = Theme.build(this, p)
        try {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).addPrimaryClipChangedListener { captureClip() }
        } catch (e: Exception) {
        }
    }

    override fun onEvaluateFullscreenMode() = false

    override fun onCreateInputView(): View {
        kbd = KeyboardView(this, p, this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // --- top bar: suggestions
        val topBar = FrameLayout(this)
        sugRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        sugRow.addView(tv("📋", 20f).also { it.setOnClickListener { openPanel(2) } }, LinearLayout.LayoutParams(dp(46), dp(44)))
        for (i in 0..2) {
            val t = tv("", 17f)
            t.setOnClickListener { pick(i) }
            sugs.add(t)
            sugRow.addView(t, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        sugRow.addView(tv("⚙", 20f).also { it.setOnClickListener { openSettings() } }, LinearLayout.LayoutParams(dp(46), dp(44)))
        topBar.addView(sugRow, FrameLayout.LayoutParams(-1, dp(44)))

        // --- top bar: panel (search)
        panelRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE }
        searchTv = tv("", 15f).apply { gravity = Gravity.CENTER_VERTICAL or Gravity.START; setPadding(dp(14), 0, dp(14), 0) }
        searchTv.setOnClickListener { startSearch() }
        panelRow.addView(searchTv, LinearLayout.LayoutParams(0, dp(34), 1f).apply { setMargins(dp(8), 0, dp(4), 0) })
        searchX = tv("✕", 18f).also { it.setOnClickListener { stopSearch() } }
        panelRow.addView(searchX, LinearLayout.LayoutParams(dp(44), dp(44)))
        clearTv = tv("Clear", 15f).also { it.setOnClickListener { io.execute { db.clearUnpinned(); hnd.post { refreshPanel() } } } }
        panelRow.addView(clearTv, LinearLayout.LayoutParams(dp(64), dp(44)))
        topBar.addView(panelRow, FrameLayout.LayoutParams(-1, dp(44)))
        root.addView(topBar, LinearLayout.LayoutParams(-1, dp(44)))

        // --- panel body
        panelFrame = FrameLayout(this).apply { visibility = View.GONE }
        emojiGrid = GridView(this).apply {
            numColumns = GridView.AUTO_FIT
            columnWidth = dp(44)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            adapter = emojiAdapter
            setOnItemClickListener { _, _, pos, _ -> commitEmoji(emojiAdapter.items[pos]) }
        }
        clipList = ListView(this).apply {
            divider = ColorDrawable(0)
            dividerHeight = dp(6)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            clipToPadding = false
            adapter = clipAdapter
            visibility = View.GONE
        }
        emptyTv = tv("", 15f).apply { alpha = 0.6f; visibility = View.GONE }
        panelFrame.addView(emojiGrid, FrameLayout.LayoutParams(-1, -1))
        panelFrame.addView(clipList, FrameLayout.LayoutParams(-1, -1))
        panelFrame.addView(emptyTv, FrameLayout.LayoutParams(-1, -1))
        root.addView(panelFrame, LinearLayout.LayoutParams(-1, dp(150)))
        root.addView(kbd, LinearLayout.LayoutParams(-1, -2))

        // --- bottom bar for panels
        bottomBar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE }
        bottomBar.addView(tv("ABC", 16f).also { it.setOnClickListener { closePanel() } }, LinearLayout.LayoutParams(dp(56), dp(46)))
        val catRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        for (i in Emoji.icons.indices) {
            val t = tv(Emoji.icons[i], 20f)
            t.setOnClickListener { cat = i; markCat(); refreshPanel() }
            catViews.add(t)
            catRow.addView(t, LinearLayout.LayoutParams(dp(42), dp(40)))
        }
        catScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(catRow) }
        bottomBar.addView(catScroll, LinearLayout.LayoutParams(0, dp(46), 1f))
        spacer = View(this)
        bottomBar.addView(spacer, LinearLayout.LayoutParams(0, dp(46), 1f))
        btnTone = tv("👋", 20f).also { it.setOnClickListener { cycleTone() } }
        bottomBar.addView(btnTone, LinearLayout.LayoutParams(dp(46), dp(46)))
        val del = tv("⌫", 20f)
        del.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { onDelete(); hnd.postDelayed(delRun, 400) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> hnd.removeCallbacks(delRun)
            }
            true
        }
        bottomBar.addView(del, LinearLayout.LayoutParams(dp(56), dp(46)))
        root.addView(bottomBar, LinearLayout.LayoutParams(-1, dp(46)))

        applyTheme()
        markCat()
        return root
    }

    private val delRun: Runnable = object : Runnable {
        override fun run() { onDelete(); hnd.postDelayed(this, 60) }
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!::root.isInitialized) return
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val v = info.inputType and InputType.TYPE_MASK_VARIATION
        val blocked = setOf(
            InputType.TYPE_TEXT_VARIATION_PASSWORD, InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD, InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS,
            InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS, InputType.TYPE_TEXT_VARIATION_URI
        )
        smart = cls == InputType.TYPE_CLASS_TEXT && v !in blocked &&
            (info.inputType and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) == 0
        applyTheme()
        mode = 0
        searching = false
        query = ""
        lastFix = null
        val numeric = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE || cls == InputType.TYPE_CLASS_DATETIME
        kbd.setMode(if (numeric) 1 else 0)
        val noAct = (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        val action = info.imeOptions and EditorInfo.IME_MASK_ACTION
        val (label, acc) = if (noAct) "return" to false else when (action) {
            EditorInfo.IME_ACTION_GO -> "go" to true
            EditorInfo.IME_ACTION_SEARCH -> "search" to true
            EditorInfo.IME_ACTION_SEND -> "send" to true
            EditorInfo.IME_ACTION_NEXT -> "next" to true
            EditorInfo.IME_ACTION_DONE -> "done" to true
            else -> "return" to false
        }
        kbd.setEnter(label, acc)
        render()
        refreshSug()
        updateShift()
        captureClip()
    }

    override fun onWindowShown() {
        super.onWindowShown()
        if (Build.VERSION.SDK_INT >= 31 && ::th.isInitialized) {
            try {
                window?.window?.setBackgroundBlurRadius(if (th.glass) (p.blur * 1.2f).toInt() else 0)
            } catch (e: Throwable) {
            }
        }
    }

    override fun onUpdateSelection(os: Int, oe: Int, ns: Int, ne: Int, cs: Int, ce: Int) {
        super.onUpdateSelection(os, oe, ns, ne, cs, ce)
        if (::root.isInitialized && mode == 0) { refreshSug(); updateShift() }
    }

    // ------------------------------------------------------------ theme
    private fun applyTheme() {
        th = Theme.build(this, p)
        loadBg()
        root.background = BgDrawable(th, bgBmp, resources.displayMetrics.density)
        tint(root)
        searchTv.background = pill(th.letter)
        val pad = (resources.displayMetrics.widthPixels * 0.16f).toInt()
        when (p.oneHand) {
            1 -> root.setPadding(0, 0, pad, 0)
            2 -> root.setPadding(pad, 0, 0, 0)
            else -> root.setPadding(0, 0, 0, 0)
        }
        kbd.applyPrefs()
        emojiAdapter.notifyDataSetChanged()
    }

    private fun loadBg() {
        val f = File(filesDir, "bg.jpg")
        if (p.bgImage.isEmpty() || !f.exists()) { bgBmp = null; bgStamp = -1; return }
        if (f.lastModified() != bgStamp) {
            bgBmp = try { BitmapFactory.decodeFile(f.path) } catch (e: Throwable) { null }
            bgStamp = f.lastModified()
        }
    }

    private fun tint(v: View) {
        if (v is TextView) v.setTextColor(th.text)
        if (v is ViewGroup) for (i in 0 until v.childCount) tint(v.getChildAt(i))
    }

    private fun pill(color: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(10).toFloat() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float) = TextView(this).apply {
        text = t
        textSize = size
        gravity = Gravity.CENTER
        setTextColor(th.text)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }

    // ------------------------------------------------------------ panels
    private fun kbHeight() = dp(p.keyH) * (if (p.numRow) 5 else 4) + dp(14)

    private fun render() {
        val typing = mode == 0
        sugRow.visibility = if (typing) View.VISIBLE else View.GONE
        panelRow.visibility = if (typing) View.GONE else View.VISIBLE
        searchX.visibility = if (searching) View.VISIBLE else View.GONE
        clearTv.visibility = if (mode == 2 && !searching) View.VISIBLE else View.GONE
        panelFrame.visibility = if (typing) View.GONE else View.VISIBLE
        kbd.visibility = if (typing || searching) View.VISIBLE else View.GONE
        bottomBar.visibility = if (typing || searching) View.GONE else View.VISIBLE
        catScroll.visibility = if (mode == 1) View.VISIBLE else View.GONE
        btnTone.visibility = if (mode == 1) View.VISIBLE else View.GONE
        spacer.visibility = if (mode == 1) View.GONE else View.VISIBLE
        val h = if (searching) dp(p.keyH) * 2 else kbHeight() - dp(46)
        panelFrame.layoutParams = LinearLayout.LayoutParams(-1, h)
        val what = if (mode == 1) "emoji" else "clipboard"
        searchTv.text = if (searching) (if (query.isEmpty()) "Type to search $what…" else query) else "🔍  Search $what"
        searchTv.alpha = if (searching && query.isNotEmpty()) 1f else 0.6f
        btnTone.text = "👋" + (if (p.tone > 0) String(Character.toChars(0x1F3FA + p.tone)) else "")
    }

    private fun markCat() {
        for (i in catViews.indices) catViews[i].background = if (i == cat && mode == 1) pill(th.letter) else null
    }

    private fun openPanel(m: Int) {
        if (mode == m) { closePanel(); return }
        mode = m
        searching = false
        query = ""
        render()
        markCat()
        refreshPanel()
    }

    private fun closePanel() {
        mode = 0
        searching = false
        query = ""
        render()
        refreshSug()
        updateShift()
    }

    private fun startSearch() { searching = true; query = ""; render(); refreshPanel() }
    private fun stopSearch() { searching = false; query = ""; render(); refreshPanel() }

    private fun refreshSearch() { render(); refreshPanel() }

    private fun cycleTone() {
        p.put("tone", (p.tone + 1) % 6)
        render()
        refreshPanel()
    }

    private fun recents(): List<String> = p.recents.split("|").filter { it.isNotEmpty() }

    private fun addRecent(e: String) {
        val l = recents().toMutableList()
        l.remove(e)
        l.add(0, e)
        p.put("recents", l.take(48).joinToString("|"))
    }

    private fun refreshPanel() {
        if (mode == 1) {
            emojiGrid.visibility = View.VISIBLE
            clipList.visibility = View.GONE
            val items = when {
                searching && query.isNotEmpty() -> Emoji.search(query).map { Emoji.withTone(it, p.tone) }
                searching || cat == 0 -> recents()
                else -> Emoji.get(cat).map { Emoji.withTone(it, p.tone) }
            }
            emojiAdapter.items = items
            emojiAdapter.notifyDataSetChanged()
            emojiGrid.setSelection(0)
            emptyTv.text = if (items.isEmpty()) (if (searching && query.isNotEmpty()) "No emoji found" else "Nothing here yet") else ""
            emptyTv.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        } else if (mode == 2) {
            emojiGrid.visibility = View.GONE
            clipList.visibility = View.VISIBLE
            val q = query
            io.execute {
                val list = db.clips(q)
                hnd.post {
                    if (mode == 2 && q == query) {
                        clipAdapter.items = list
                        clipAdapter.notifyDataSetChanged()
                        emptyTv.text = if (list.isEmpty()) "Copy something and it will show up here" else ""
                        emptyTv.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                    }
                }
            }
        }
    }

    private fun commitEmoji(e: String) {
        currentInputConnection?.commitText(e, 1)
        addRecent(e)
    }

    private fun commitClip(c: Clip) {
        io.execute {
            val t = db.clipText(c.id)
            hnd.post { currentInputConnection?.commitText(t, 1); closePanel() }
        }
    }

    inner class EmojiAdapter : BaseAdapter() {
        var items: List<String> = emptyList()
        override fun getCount() = items.size
        override fun getItem(i: Int) = items[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, cv: View?, parent: ViewGroup?): View {
            val t = (cv as? TextView) ?: TextView(this@KeyboardService).apply {
                gravity = Gravity.CENTER
                textSize = 26f
                layoutParams = AbsListView.LayoutParams(dp(44), dp(44))
            }
            t.text = items[i]
            t.setTextColor(th.text)
            return t
        }
    }

    inner class ClipAdapter : BaseAdapter() {
        var items: List<Clip> = emptyList()
        override fun getCount() = items.size
        override fun getItem(i: Int) = items[i]
        override fun getItemId(i: Int) = items[i].id
        override fun getView(i: Int, cv: View?, parent: ViewGroup?): View {
            val c = items[i]
            val ctx = this@KeyboardService
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = pill(th.letter)
                setPadding(dp(12), dp(8), dp(2), dp(8))
                layoutParams = AbsListView.LayoutParams(-1, -2)
            }
            val t = TextView(ctx).apply {
                text = c.text
                textSize = 14f
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(th.text)
            }
            row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            val pin = tv("📌", 16f).apply { alpha = if (c.pinned) 1f else 0.3f }
            pin.setOnClickListener { io.execute { db.pin(c.id, !c.pinned); hnd.post { refreshPanel() } } }
            row.addView(pin, LinearLayout.LayoutParams(dp(40), dp(36)))
            val del = tv("✕", 15f)
            del.setOnClickListener { io.execute { db.del(c.id); hnd.post { refreshPanel() } } }
            row.addView(del, LinearLayout.LayoutParams(dp(40), dp(36)))
            row.setOnClickListener { commitClip(c) }
            return row
        }
    }

    private fun captureClip() {
        try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip ?: return
            if (clip.itemCount == 0) return
            if (clip.description?.extras?.getBoolean("android.content.extra.IS_SENSITIVE") == true) return
            val t = clip.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: return
            if (t.isNotEmpty() && t.length < 100000 && t != lastClip) {
                lastClip = t
                io.execute { db.addClip(t) }
            }
        } catch (e: Exception) {
        }
    }

    private fun openSettings() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ------------------------------------------------------------ text helpers
    private fun currentWord(ic: InputConnection): String {
        val t = ic.getTextBeforeCursor(40, 0)?.toString() ?: return ""
        var i = t.length
        while (i > 0 && (t[i - 1].isLetter() || t[i - 1] == '\'' || t[i - 1] == '’')) i--
        return t.substring(i).replace('’', '\'')
    }

    private fun prevWord(ic: InputConnection): String? {
        val t = ic.getTextBeforeCursor(60, 0)?.toString() ?: return null
        var i = t.length
        while (i > 0 && (t[i - 1].isLetter() || t[i - 1] == '\'')) i--
        var j = i
        while (j > 0 && t[j - 1] == ' ') j--
        if (j == i || j == 0) return null
        var k = j
        while (k > 0 && (t[k - 1].isLetter() || t[k - 1] == '\'')) k--
        return if (k < j) t.substring(k, j).lowercase() else null
    }

    private fun finishWord(ic: InputConnection, w: String) {
        val prev = prevWord(ic)
        var fin = w
        if (p.autoCorrect) {
            val fix = dict.fix(w)
            if (fix != null && fix != w) {
                ic.deleteSurroundingText(w.length, 0)
                ic.commitText(fix, 1)
                lastFix = w to fix
                fin = fix
            }
        }
        dict.learn(prev, fin.lowercase())
    }

    private fun afterEdit() { refreshSug(); updateShift() }

    private fun updateShift() {
        if (!::kbd.isInitialized || !p.autoCap || mode != 0) return
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo ?: return
        if ((ei.inputType and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT) return
        kbd.setAutoShift(ic.getCursorCapsMode(ei.inputType) != 0)
    }

    private fun refreshSug() {
        if (!::kbd.isInitialized || mode != 0) return
        sugData.fill(null)
        val ic = currentInputConnection
        if (ic != null && p.suggest && smart) {
            val w = currentWord(ic)
            if (w.isEmpty()) {
                val n = dict.next(prevWord(ic))
                sugData[1] = n.getOrNull(0)?.let { Sug(it, false) }
                sugData[0] = n.getOrNull(1)?.let { Sug(it, false) }
                sugData[2] = n.getOrNull(2)?.let { Sug(it, false) }
            } else {
                val lw = w.lowercase()
                val c = dict.complete(lw, 3).map { applyCase(w, it) }
                val literal = !dict.known(lw)
                sugData[1] = c.getOrNull(0)?.let { Sug(it, false) }
                if (literal) {
                    sugData[0] = Sug(w, true)
                    sugData[2] = c.getOrNull(1)?.let { Sug(it, false) }
                } else {
                    sugData[0] = c.getOrNull(1)?.let { Sug(it, false) }
                    sugData[2] = c.getOrNull(2)?.let { Sug(it, false) }
                }
            }
        }
        for (i in 0..2) {
            val s = sugData[i]
            sugs[i].text = if (s == null) "" else if (s.literal) "\u201C${s.text}\u201D" else s.text
            sugs[i].setTypeface(null, if (i == 1) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    private fun pick(i: Int) {
        val s = sugData[i] ?: return
        val ic = currentInputConnection ?: return
        val w = currentWord(ic)
        val prev = prevWord(ic)
        if (w.isNotEmpty()) ic.deleteSurroundingText(w.length, 0)
        ic.commitText(s.text + " ", 1)
        lastFix = null
        if (smart) dict.learn(prev, s.text.lowercase())
        if (s.literal) dict.boost(s.text.lowercase())
        afterEdit()
    }

    // ------------------------------------------------------------ KeyboardView.Callback
    override fun onText(s: String) {
        if (searching) { query += s; refreshSearch(); return }
        val ic = currentInputConnection ?: return
        lastFix = null
        val c = s[0]
        if (smart && s.length == 1 && !c.isLetterOrDigit() && c != '\'' && c != '’') {
            val w = currentWord(ic)
            if (w.isNotEmpty()) finishWord(ic, w)
        }
        ic.commitText(s, 1)
        afterEdit()
    }

    override fun onSpace() {
        if (searching) { query += " "; refreshSearch(); return }
        val ic = currentInputConnection ?: return
        val w = currentWord(ic)
        if (p.dblSpace && w.isEmpty()) {
            val b = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
            if (b.length == 2 && b[1] == ' ' && b[0].isLetterOrDigit()) {
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                lastFix = null
                afterEdit()
                return
            }
        }
        lastFix = null
        if (smart && w.isNotEmpty()) finishWord(ic, w)
        ic.commitText(" ", 1)
        afterEdit()
    }

    override fun onDelete() {
        if (searching) {
            if (query.isNotEmpty()) { query = query.dropLast(1); refreshSearch() }
            return
        }
        val ic = currentInputConnection ?: return
        val lf = lastFix
        if (lf != null) {
            val orig = lf.first
            val fixed = lf.second
            val before = ic.getTextBeforeCursor(fixed.length + 1, 0)?.toString() ?: ""
            lastFix = null
            if (before.length == fixed.length + 1 && before.startsWith(fixed)) {
                ic.beginBatchEdit()
                ic.deleteSurroundingText(fixed.length + 1, 0)
                ic.commitText(orig + before.last(), 1)
                ic.endBatchEdit()
                dict.boost(orig.lowercase())
                afterEdit()
                return
            }
        }
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        afterEdit()
    }

    override fun onEnter() {
        if (searching) return
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        if (smart) {
            val w = currentWord(ic)
            if (w.isNotEmpty()) finishWord(ic, w)
        }
        lastFix = null
        val a = ei.imeOptions and EditorInfo.IME_MASK_ACTION
        if ((ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0 ||
            a == EditorInfo.IME_ACTION_NONE || a == EditorInfo.IME_ACTION_UNSPECIFIED
        ) sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) else ic.performEditorAction(a)
        afterEdit()
    }

    override fun onEmoji() { openPanel(1) }

    override fun onEmojiLong() {
        try { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() } catch (e: Exception) {}
    }

    override fun onCursor(steps: Int) {
        repeat(abs(steps)) {
            sendDownUpKeyEvents(if (steps > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT)
        }
    }
}
