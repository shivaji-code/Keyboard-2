GlassBoard keyboard (English + Tinglish) - build steps

1. Install Android Studio (Meerkat or newer). File > Open > select this GlassBoard folder. Let Gradle sync.
2. Uninstall the old GlassBoard from your phone first (same package name, different signing key).
3. Plug in the Galaxy S23 FE (USB debugging on) and press Run, or build the optimized APK:
   Build > Generate App Bundles or APKs > Generate APKs, variant "release"
   (release uses R8 shrinking and is signed with the debug key, so it installs directly).
4. Open GlassBoard > "1. Enable keyboard" > turn it on > "2. Switch to GlassBoard".

Word lists: app/src/main/assets/dict_en.txt and dict_tinglish.txt - one word per line, most common first.
Blur/corner values: KeyboardService.applyWindowStyle()  (blur radius 80, corner radius 4.5% of screen width).
