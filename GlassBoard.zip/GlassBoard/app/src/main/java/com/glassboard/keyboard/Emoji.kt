package com.glassboard.keyboard

import android.graphics.Paint
import java.util.Locale

/** Builds emoji lists from Unicode ranges and keeps only those the phone's font can draw. */
object Emoji {
    val icons = listOf("🕘", "😀", "🧑", "🐻", "🍔", "⚽", "🚗", "💡", "❤️", "🏳️")

    private val R: Map<Int, List<IntRange>> = mapOf(
        1 to listOf(0x1F600..0x1F644, 0x1F910..0x1F92F, 0x1F970..0x1F97F, 0x1F9D0..0x1F9D0, 0x263A..0x263A, 0x2639..0x2639),
        2 to listOf(0x1F645..0x1F64F, 0x1F440..0x1F450, 0x1F466..0x1F487, 0x1F4AA..0x1F4AA, 0x1F930..0x1F93F,
            0x1F9D1..0x1F9DF, 0x261D..0x261D, 0x270A..0x270D, 0x1F590..0x1F596, 0x1F57A..0x1F57A, 0x1F9B0..0x1F9B9),
        3 to listOf(0x1F400..0x1F43F, 0x1F980..0x1F9AF, 0x1F300..0x1F32C, 0x1F330..0x1F344, 0x1F577..0x1F578, 0x1F54A..0x1F54A),
        4 to listOf(0x1F345..0x1F37F, 0x1F950..0x1F96F, 0x1F9C0..0x1F9CB, 0x1F32D..0x1F32F),
        5 to listOf(0x1F380..0x1F3D3, 0x1F3F8..0x1F3FA, 0x1F940..0x1F94F, 0x26BD..0x26BE),
        6 to listOf(0x1F3D4..0x1F3F0, 0x1F680..0x1F6D7, 0x1F6E9..0x1F6E9, 0x1F6EB..0x1F6EC, 0x1F6F4..0x1F6FC),
        7 to listOf(0x231A..0x231B, 0x23F0..0x23F3, 0x1F488..0x1F492, 0x1F4A1..0x1F4A9, 0x1F4AB..0x1F4FF,
            0x1F550..0x1F567, 0x1F5A5..0x1F5A5, 0x1F9E0..0x1F9FF, 0x260E..0x260E, 0x2709..0x2709, 0x270F..0x270F, 0x2702..0x2702),
        8 to listOf(0x1F493..0x1F49F, 0x1F5A4..0x1F5A4, 0x1F90D..0x1F90F, 0x1F500..0x1F53D, 0x1F7E0..0x1F7EB,
            0x2764..0x2764, 0x2728..0x2728, 0x2B50..0x2B50, 0x2705..0x2705, 0x274C..0x274C, 0x2757..0x2757,
            0x2753..0x2753, 0x26A0..0x26A0, 0x2714..0x2714, 0x2795..0x2797, 0x267B..0x267B, 0x26D4..0x26D4, 0x1F4A0..0x1F4A0)
    )

    private val TONE = listOf(
        0x1F442..0x1F443, 0x1F446..0x1F450, 0x1F466..0x1F478, 0x1F47C..0x1F47C, 0x1F481..0x1F483,
        0x1F485..0x1F487, 0x1F4AA..0x1F4AA, 0x1F574..0x1F575, 0x1F57A..0x1F57A, 0x1F590..0x1F590,
        0x1F595..0x1F596, 0x1F645..0x1F647, 0x1F64B..0x1F64F, 0x1F6A3..0x1F6A3, 0x1F6B4..0x1F6B6,
        0x1F6C0..0x1F6C0, 0x1F90C..0x1F90C, 0x1F90F..0x1F90F, 0x1F918..0x1F91F, 0x1F926..0x1F926,
        0x1F930..0x1F939, 0x1F93C..0x1F93E, 0x1F9B5..0x1F9B6, 0x1F9B8..0x1F9B9, 0x1F9D1..0x1F9DD,
        0x261D..0x261D, 0x270A..0x270D, 0x1F3C2..0x1F3C4, 0x1F3C7..0x1F3C7, 0x1F3CA..0x1F3CC
    )

    private val cache = HashMap<Int, List<String>>()
    private val paint = Paint()

    private fun str(cp: Int) = String(Character.toChars(cp)) + if (cp < 0x10000) "\uFE0F" else ""

    @Synchronized
    fun get(cat: Int): List<String> = cache.getOrPut(cat) {
        if (cat == 9) flags()
        else (R[cat] ?: emptyList()).flatMap { r -> r.map { str(it) } }.filter { paint.hasGlyph(it) }
    }

    private fun flags(): List<String> {
        val out = ArrayList<String>()
        for (s in listOf("🏳️", "🏴", "🏁", "🚩", "🏳️‍🌈", "🏴‍☠️")) if (paint.hasGlyph(s)) out.add(s)
        for (a in 0 until 26) for (b in 0 until 26) {
            val s = String(Character.toChars(0x1F1E6 + a)) + String(Character.toChars(0x1F1E6 + b))
            if (paint.hasGlyph(s)) out.add(s)
        }
        return out
    }

    fun withTone(e: String, tone: Int): String {
        if (tone <= 0) return e
        val cp = e.codePointAt(0)
        return if (TONE.any { cp in it }) String(Character.toChars(cp)) + String(Character.toChars(0x1F3FB + tone - 1)) else e
    }

    private fun flagName(e: String): String {
        val a = e.codePointAt(0)
        if (a !in 0x1F1E6..0x1F1FF || e.length < 4) return ""
        val b = e.codePointAt(2)
        val code = "" + ('A' + (a - 0x1F1E6)) + ('A' + (b - 0x1F1E6))
        return Locale("", code).displayCountry.lowercase()
    }

    fun search(q: String): List<String> {
        val words = q.lowercase().trim().split(" ").filter { it.isNotEmpty() }
        if (words.isEmpty()) return emptyList()
        val out = ArrayList<String>()
        for (cat in 1..9) for (e in get(cat)) {
            val name = if (cat == 9) flagName(e) else try {
                Character.getName(e.codePointAt(0))?.lowercase() ?: ""
            } catch (x: Exception) { "" }
            if (words.all { name.contains(it) }) out.add(e)
            if (out.size >= 150) return out
        }
        return out
    }
}
