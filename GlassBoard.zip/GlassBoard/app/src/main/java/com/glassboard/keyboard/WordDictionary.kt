package com.glassboard.keyboard

import android.content.Context
import kotlin.math.abs

/**
 * Word list used for suggestions. Loads assets/dict_en.txt and assets/dict_tinglish.txt
 * (words ordered most-common first) on a background thread.
 *
 * Suggestions are prefix completions ranked by commonness, plus close typo fixes
 * (one letter wrong / missing / extra / swapped) when there are not enough completions.
 */
class WordDictionary {

    private class Data(val words: Array<String>, val scores: IntArray)

    @Volatile
    private var data: Data? = null

    fun load(context: Context) {
        val appContext = context.applicationContext
        Thread {
            try {
                val map = HashMap<String, Int>(24000)
                read(appContext, "dict_en.txt", 0, map)
                // Tinglish gets a small penalty so common English words win ties.
                read(appContext, "dict_tinglish.txt", 120, map)
                val sorted = map.keys.sorted().toTypedArray()
                val scores = IntArray(sorted.size) { map[sorted[it]] ?: Int.MAX_VALUE }
                data = Data(sorted, scores)
            } catch (_: Exception) {
                // No suggestions if the files are missing; typing still works.
            }
        }.start()
    }

    private fun read(context: Context, name: String, bias: Int, map: HashMap<String, Int>) {
        context.assets.open(name).bufferedReader().useLines { lines ->
            var i = 0
            for (line in lines) {
                for (token in line.split(' ', '\t')) {
                    val w = token.trim().lowercase()
                    if (w.isEmpty()) continue
                    val s = bias + i
                    val old = map[w]
                    if (old == null || s < old) map[w] = s
                    i++
                }
            }
        }
    }

    fun suggest(typed: String, max: Int): List<String> {
        val d = data ?: return emptyList()
        val p = typed.lowercase()
        if (p.isEmpty() || max <= 0) return emptyList()
        val ws = d.words
        val sc = d.scores

        val topW = arrayOfNulls<String>(max)
        val topS = IntArray(max) { Int.MAX_VALUE }
        fun offer(w: String, s: Int) {
            var pos = max
            while (pos > 0 && s < topS[pos - 1]) pos--
            if (pos >= max) return
            for (j in max - 1 downTo pos + 1) {
                topW[j] = topW[j - 1]
                topS[j] = topS[j - 1]
            }
            topW[pos] = w
            topS[pos] = s
        }

        var i = lowerBound(ws, p)
        while (i < ws.size && ws[i].startsWith(p)) {
            if (ws[i].length > p.length) offer(ws[i], sc[i])
            i++
        }
        val result = ArrayList<String>()
        for (w in topW) if (w != null) result.add(w)

        if (result.size < max && p.length >= 3) {
            val first = p.substring(0, 1)
            val typo = ArrayList<Int>()
            var j = lowerBound(ws, first)
            while (j < ws.size && ws[j].startsWith(first)) {
                val w = ws[j]
                if (w != p && abs(w.length - p.length) <= 1 && withinOne(p, w) && !result.contains(w)) {
                    typo.add(j)
                }
                j++
            }
            typo.sortBy { sc[it] }
            for (idx in typo) {
                if (result.size >= max) break
                result.add(ws[idx])
            }
        }
        return result
    }

    private fun lowerBound(a: Array<String>, key: String): Int {
        var lo = 0
        var hi = a.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (a[mid] < key) lo = mid + 1 else hi = mid
        }
        return lo
    }

    /** True when the two words differ by at most one insert, delete, replace or adjacent swap. */
    private fun withinOne(a: String, b: String): Boolean {
        val la = a.length
        val lb = b.length
        if (abs(la - lb) > 1) return false
        var i = 0
        while (i < la && i < lb && a[i] == b[i]) i++
        if (i == la || i == lb) return true
        return when {
            la == lb -> a.substring(i + 1) == b.substring(i + 1) ||
                (i + 1 < la && a[i] == b[i + 1] && a[i + 1] == b[i] &&
                    a.substring(i + 2) == b.substring(i + 2))
            la > lb -> a.substring(i + 1) == b.substring(i)
            else -> a.substring(i) == b.substring(i + 1)
        }
    }
}
