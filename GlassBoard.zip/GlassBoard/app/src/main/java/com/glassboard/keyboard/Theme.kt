package com.glassboard.keyboard

import android.content.Context
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.Drawable

class Th(
    val dark: Boolean, val glass: Boolean, val g: Float,
    val bg: Int, val letter: Int, val special: Int, val shadow: Int,
    val text: Int, val bubble: Int, val accent: Int
)

object Theme {
    fun build(ctx: Context, p: Prefs): Th {
        val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val dark = p.theme == 2 || (p.theme == 0 && night)
        val glass = p.style == 1
        val g = p.glass / 100f
        val acc = p.accent
        if (!glass) {
            return if (dark) Th(dark, false, g, 0xFF1C1C1E.toInt(), 0xFF6A6A6E.toInt(), 0xFF454548.toInt(),
                0xFF0B0B0C.toInt(), 0xFFFFFFFF.toInt(), 0xFF6A6A6E.toInt(), acc)
            else Th(dark, false, g, 0xFFD1D4DA.toInt(), 0xFFFFFFFF.toInt(), 0xFFABB0BB.toInt(),
                0xFF888B90.toInt(), 0xFF000000.toInt(), 0xFFFFFFFF.toInt(), acc)
        }
        val a1 = (50 + 150 * g).toInt()
        return if (dark) Th(dark, true, g, Color.argb((60 + 120 * g).toInt(), 10, 10, 14),
            Color.argb((a1 * 0.40f).toInt(), 255, 255, 255), Color.argb((a1 * 0.20f).toInt(), 255, 255, 255),
            0, 0xFFFFFFFF.toInt(), 0xF0404044.toInt(), acc)
        else Th(dark, true, g, Color.argb((40 + 110 * g).toInt(), 255, 255, 255),
            Color.argb(a1, 255, 255, 255), Color.argb((a1 * 0.55f).toInt(), 255, 255, 255),
            0, 0xFF000000.toInt(), 0xF2FFFFFF.toInt(), acc)
    }
}

/** Keyboard backdrop: solid colour, frosted glass tint, or your own picture. */
class BgDrawable(private val th: Th, private val bmp: Bitmap?, private val d: Float) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun draw(c: Canvas) {
        val b = bounds
        if (bmp != null) {
            val s = maxOf(b.width() / bmp.width.toFloat(), b.height() / bmp.height.toFloat())
            val dw = bmp.width * s
            val dh = bmp.height * s
            val l = b.left + (b.width() - dw) / 2
            val t = b.top + (b.height() - dh) / 2
            c.drawBitmap(bmp, null, RectF(l, t, l + dw, t + dh), paint)
            paint.color = if (th.dark) Color.argb(120, 0, 0, 0) else Color.argb(80, 255, 255, 255)
            c.drawRect(b, paint)
        }
        if (th.glass || bmp == null) {
            paint.color = th.bg
            c.drawRect(b, paint)
        }
        if (th.glass) {
            paint.shader = LinearGradient(0f, b.top.toFloat(), 0f, b.bottom.toFloat(),
                Color.argb((70 * th.g + 20).toInt(), 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
            c.drawRect(b, paint)
            paint.shader = null
            paint.color = Color.argb(110, 255, 255, 255)
            c.drawRect(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.top + d, paint)
        }
    }

    override fun setAlpha(a: Int) {}
    override fun setColorFilter(f: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}
