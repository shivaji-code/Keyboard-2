# GlassBoard keyboard (Android)

Open this folder in Android Studio -> wait for Gradle sync -> Build > Build APK(s).
APK appears in app/build/outputs/apk/debug/app-debug.apk

Or push to GitHub: the workflow in .github/workflows/build.yml builds the APK
(Actions tab -> latest run -> Artifacts -> GlassBoard-debug-apk).

Words for autocorrect: app/src/main/assets/dict_en.txt and dict_tinglish.txt
(plain words separated by spaces/newlines, most common first). Add more any time.
